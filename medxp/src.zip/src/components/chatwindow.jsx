import React from "react";
import Message from "./message";

export default function ChatWindow({ messages }) {
  return (
    <div id="chat-window" className="flex-grow p-4 space-y-4 overflow-y-auto max-h-[70vh]">
      {messages.map((msg, i) => (
        <Message key={i} sender={msg.sender} text={msg.text} sources={msg.sources} />
      ))}
    </div>
  );
}
